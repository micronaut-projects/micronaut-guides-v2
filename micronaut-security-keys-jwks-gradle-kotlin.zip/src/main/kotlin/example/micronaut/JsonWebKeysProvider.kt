/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import com.nimbusds.jose.jwk.JWK
import io.micronaut.runtime.context.scope.Refreshable
import io.micronaut.security.token.jwt.endpoints.JwkProvider

@Refreshable // <1>
class JsonWebKeysProvider(primaryRsaPrivateKey: PrimarySignatureConfiguration,
                          secondarySignatureConfiguration: SecondarySignatureConfiguration) : JwkProvider { // <2>

    private val jwks: List<JWK>

    init {
        jwks = listOf(primaryRsaPrivateKey.publicJWK, secondarySignatureConfiguration.publicJWK)
    }

    override fun retrieveJsonWebKeys(): List<JWK> = jwks
}
