/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut.domain

import com.fasterxml.jackson.annotation.JsonAnyGetter
import com.fasterxml.jackson.annotation.JsonAnySetter
import io.micronaut.data.annotation.GeneratedValue
import io.micronaut.data.annotation.Id
import io.micronaut.data.annotation.MappedEntity
import io.micronaut.data.annotation.Relation
import io.micronaut.data.annotation.sql.JoinTable

@MappedEntity(value = "TBL_STUDENT", alias = "s") // <1>
class Student {
    @Id // <2>
    @GeneratedValue(GeneratedValue.Type.IDENTITY) // <3>
    Long id
    String name

    @JoinTable(name = "TBL_STUDENT_CLASSES", alias = "sc") // <4>
    @Relation(Relation.Kind.MANY_TO_MANY) // <5>
    List<Class> classes

    @JsonAnyGetter // <6>
    @JsonAnySetter
    private Map<String, Object> extras

    Map<String, Object> getExtras() {
        extras
    }

    void setExtras(Map<String, Object> extras) {
        this.extras = extras
    }
}
