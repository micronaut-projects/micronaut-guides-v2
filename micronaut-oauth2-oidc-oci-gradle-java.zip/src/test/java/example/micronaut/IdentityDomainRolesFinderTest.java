/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut;

import io.micronaut.security.token.RolesFinder;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

@MicronautTest(startApplication = false)
class IdentityDomainRolesFinderTest {

    @Test
    void testFindRoles(RolesFinder rolesFinder) {
        assertInstanceOf(IdentityDomainRolesFinder.class, rolesFinder);
        List<String> roles = rolesFinder.resolveRoles(Map.of("groups", List.of(Map.of("name", "ROLE_ADMIN", "id", "cab3a10ad56935ca1726464bcaa12a34"))));
        List<String> expectedRoles = List.of("ROLE_ADMIN");
        assertEquals(expectedRoles, roles);

        roles = rolesFinder.resolveRoles(Collections.emptyMap());
        expectedRoles = Collections.emptyList();
        assertEquals(expectedRoles, roles);

        roles = rolesFinder.resolveRoles(Map.of("groups", "foo"));
        assertEquals(expectedRoles, roles);
    }

}