/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import groovy.transform.CompileStatic
import io.micronaut.data.annotation.Id
import io.micronaut.data.annotation.MappedEntity
import io.micronaut.serde.annotation.Serdeable

@CompileStatic
@Serdeable
@MappedEntity('inventory_item')
class InventoryItem {

    @Id
    Long id

    String name

    int availableQuantity

    Status status

    InventoryItem() {
    }

    InventoryItem(Long id, String name, int availableQuantity, Status status) {
        this.id = id
        this.name = name
        this.availableQuantity = availableQuantity
        this.status = status
    }

    InventoryItem withStatus(Status status) {
        new InventoryItem(id, name, availableQuantity, status)
    }
}
