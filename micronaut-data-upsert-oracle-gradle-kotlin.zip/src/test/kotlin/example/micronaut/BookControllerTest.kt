/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.extensions.junit5.annotation.MicronautTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInstance

@TestInstance(TestInstance.Lifecycle.PER_CLASS) // <1>
@MicronautTest // <2>
class BookControllerTest : AbstractTest() { // <3>

    @Test
    fun bookUpsert(repository: BookRepository, // <4>
                   @Client("/") httpClient: HttpClient) { // <5>
        val client = httpClient.toBlocking()
        val path = "/books"
        val title = "Netty in Action"
        assertNull(repository.findByTitle(title)) // <6>

        val postResponse = client.exchange<Map<String, Any>, Any>(
            HttpRequest.POST(path, mapOf("id" to 123L, "title" to title)))
        assertEquals(HttpStatus.CREATED, postResponse.status) // <7>
        assertNotNull(repository.findByTitle(title))
        assertNull(repository.findByTitle(title)?.pages)

        val putResponse = client.exchange<Map<String, Any>, Any>(
            HttpRequest.PUT(path, mapOf("id" to 123L, "title" to title, "pages" to 265)))
        assertEquals(HttpStatus.OK, putResponse.status) // <8>
        assertNotNull(repository.findByTitle(title)?.pages) // <9>
    }
}
