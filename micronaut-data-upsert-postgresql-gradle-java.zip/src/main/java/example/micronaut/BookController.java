/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut;

import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.Put;
import io.micronaut.http.annotation.Status;

@Controller("/books") // <1>
class BookController {
    private final BookRepository bookRepository;

    BookController(BookRepository bookRepository) { // <2>
        this.bookRepository = bookRepository;
    }

    @Post // <3>
    @Status(HttpStatus.CREATED) // <4>
    void save(@Body Book book) { // <5>
        bookRepository.upsert(book); // <6>
    }

    @Put // <7>
    @Status(HttpStatus.OK)
    void update(@Body Book book) {
        bookRepository.upsert(book); // <6>
    }
}