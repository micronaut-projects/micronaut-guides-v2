/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import io.micronaut.email.BodyType
import io.micronaut.email.BodyType.TEXT
import io.micronaut.email.Email
import io.micronaut.email.TransactionalEmailSender
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus.OK
import io.micronaut.http.MediaType.MULTIPART_FORM_DATA_TYPE
import io.micronaut.http.MediaType.TEXT_CSV
import io.micronaut.http.MediaType.TEXT_CSV_TYPE
import io.micronaut.http.MediaType.TEXT_PLAIN_TYPE
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.client.multipart.MultipartBody
import io.micronaut.test.annotation.MockBean
import io.micronaut.test.extensions.junit5.annotation.MicronautTest
import jakarta.inject.Named
import jakarta.mail.Message
import jakarta.validation.Valid
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import java.nio.charset.StandardCharsets.UTF_8
import java.util.function.Consumer

@MicronautTest // <1>
class EmailControllerTest(@Client("/") val client: HttpClient) { // <2>

    var emails: MutableList<Email> = mutableListOf()

    @AfterEach
    fun cleanup() {
        emails.clear()
    }

    @Test
    fun testBasic() {

        val response: HttpResponse<String> = client.toBlocking().exchange(
            HttpRequest.POST("/email/basic", ""),
            String::class.java
        )
        assertEquals(response.status(), OK)

        assertEquals(1, emails.size)
        val email = emails[0]

        assertEquals("test@test.com", email.from.email)

        assertNull(email.replyTo)

        assertNotNull(email.to)
        assertEquals(1, email.to!!.size)
        assertEquals("basic@domain.com", email.to!!.iterator().next().email)
        assertNull(email.to!!.iterator().next().name)

        assertNull(email.cc)

        assertNull(email.bcc)

        assertTrue(email.subject.startsWith("Micronaut Email Basic Test: "))

        assertNull(email.attachments)

        val body = email.body?.get(TEXT)
        assertEquals("Basic email", body?.orElseThrow())
    }

    @Test
    fun testTemplate() {

        val response: HttpResponse<String> = client.toBlocking().exchange(
            HttpRequest.POST("/email/template/testingtesting", ""),
            String::class.java
        )
        assertEquals(response.status(), OK)

        assertEquals(1, emails.size)
        val email = emails[0]

        assertEquals("test@test.com", email.from.email)

        assertNull(email.replyTo)

        assertNotNull(email.to)
        assertEquals(1, email.to!!.size)
        assertEquals("template@domain.com", email.to!!.iterator().next().email)
        assertNull(email.to!!.iterator().next().name)

        assertNull(email.cc)

        assertNull(email.bcc)

        assertTrue(email.subject.startsWith("Micronaut Email Template Test: "))

        assertNull(email.attachments)

        val body = email.body?.get(BodyType.HTML)
        assertTrue(body?.orElseThrow()?.contains("Hello, <span>testingtesting</span>!") == true)
    }

    @Test
    fun testAttachment() {

        val response: HttpResponse<*> = client.toBlocking().exchange(
            HttpRequest.POST("/email/attachment", MultipartBody.builder()
                .addPart("file", "test.csv", TEXT_CSV_TYPE, "test,email".toByteArray(UTF_8))
                .build())
                .contentType(MULTIPART_FORM_DATA_TYPE)
                .accept(TEXT_PLAIN_TYPE),
            String::class.java
        )
        assertEquals(response.status(), OK)

        assertEquals(1, emails.size)
        val email = emails[0]

        assertEquals("test@test.com", email.from.email)

        assertNull(email.replyTo)

        assertNotNull(email.to)
        assertEquals(1, email.to!!.size)
        assertEquals("attachment@domain.com", email.to!!.iterator().next().email)
        assertNull(email.to!!.iterator().next().name)

        assertNull(email.cc)

        assertNull(email.bcc)

        assertTrue(email.subject.startsWith("Micronaut Email Attachment Test: "))

        assertNotNull(email.attachments)
        assertEquals(1, email.attachments!!.size)
        val attachment = email.attachments!![0]
        assertEquals("test.csv", attachment.filename)
        assertTrue(attachment.contentType.contains(TEXT_CSV), attachment.contentType)
        assertEquals("test,email", String(attachment.content))

        val body = email.body?.get(TEXT)
        assertEquals("Attachment email", body?.orElseThrow())
    }

    @MockBean(TransactionalEmailSender::class)
    @Named("mock")
    fun mockSender(): TransactionalEmailSender<Message, Unit> = object : TransactionalEmailSender<Message, Unit> {

        override fun getName() = "test"

        override fun send(@Valid email: Email, emailRequest: Consumer<Message>) {
            emails.add(email)
        }
    }
}
