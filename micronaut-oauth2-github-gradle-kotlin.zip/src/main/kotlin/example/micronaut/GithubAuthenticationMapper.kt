/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import io.micronaut.security.authentication.AuthenticationResponse
import io.micronaut.security.oauth2.endpoint.authorization.state.State
import io.micronaut.security.oauth2.endpoint.token.response.OauthAuthenticationMapper
import io.micronaut.security.oauth2.endpoint.token.response.TokenResponse
import jakarta.inject.Named
import jakarta.inject.Singleton
import org.reactivestreams.Publisher
import reactor.core.publisher.Mono

@Named("github") // <1>
@Singleton
class GithubAuthenticationMapper(private val apiClient: GithubApiClient) : OauthAuthenticationMapper {

    override fun createAuthenticationResponse(
        tokenResponse: TokenResponse,
        state: State?
    ): Publisher<AuthenticationResponse> =
        Mono.from(apiClient.getUser(TOKEN_PREFIX + tokenResponse.accessToken)) // <2>
            .map { (login): GithubUser -> AuthenticationResponse.success(login,
                listOf(ROLE_GITHUB),
                mapOf(OauthAuthenticationMapper.ACCESS_TOKEN_KEY to tokenResponse.accessToken)) // <3>
            }

    companion object {
        const val TOKEN_PREFIX = "token "
        const val ROLE_GITHUB = "ROLE_GITHUB"
    }
}
